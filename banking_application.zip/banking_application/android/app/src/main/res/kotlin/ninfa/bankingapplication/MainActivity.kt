package ninfa.bankingapplication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
